﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace gorselodevim
{
    public partial class UyeEkleme : Form
    {
        public UyeEkleme()
        {
            InitializeComponent();
        }

     

        private void btn_ekle_uye_Click(object sender, EventArgs e)
        {
            if (kullanici_adi.Text == "" || kullanici_adres.Text == "" || kullanici_mail.Text == "" || kullanici_tel.Text == "" || kullanici_pass.Text == "" || kullanici_cins.Text == "")
            {
                 MessageBox.Show("Lütfen bos alan bırakmayın");
            }
            else{

           
            string str = @"Data Source=(LocalDB)\v11.0;AttachDbFilename='c:\users\cagri\documents\visual studio 2013\Projects\gorselodevim\gorselodevim\kitapDB.mdf';Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("insert into Uye(kullanici_ad,kullanici_adres,kullanici_tel,kullanici_mail,kullanici_pass,kullanici_cinsiyet)values(@a,@b,@c,@d,@e,@f)", con);

                cmd.Parameters.AddWithValue("@a",kullanici_adi.Text);
            cmd.Parameters.AddWithValue("@b", kullanici_adres.Text);
            cmd.Parameters.AddWithValue("@c", kullanici_tel.Text);
            cmd.Parameters.AddWithValue("@d",kullanici_mail.Text);
            cmd.Parameters.AddWithValue("@e", kullanici_pass.Text);
            cmd.Parameters.AddWithValue("@f", kullanici_cins.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show(" Bilgiler Eklendi");
            kullanici_adi.Text = "";
            kullanici_adres.Text = "";
            kullanici_tel.Text = "";
            kullanici_mail.Text = "";
            kullanici_pass.Text = "";
            kullanici_cins.Text = "";
            kullanici_adi.Focus();


            con.Close();
                 }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
